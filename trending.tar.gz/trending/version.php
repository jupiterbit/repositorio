<?php
defined('MOODLE_INTERNAL') || die;
$plugin->version   = 2014051200;
$plugin->requires  = 2014050800;
$plugin->component = 'theme_trending';
$plugin->dependencies = array(
    'theme_bootstrapbase'  => 2014050800,
    'theme_clean'  => 2014050800,
);