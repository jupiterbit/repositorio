<?php if($displayaboutussection) { ?>
<section id="about">
		<div class="container-fluid">
			<div class="center">
				<div class="heading">
                    <?php if($aboutusheading) { ?>
					<h2><?php echo $aboutusheading ?></h2>
                    <?php } ?>
                    <?php if($aboutustagline) { ?>
					<p class="tagline"><?php echo $aboutustagline ?></p>
                    <?php } ?>
				</div>
			</div>
		</div>
	
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span6 wow fadeInRight">
					<img src="<?php echo $aboutusimage ?>" class="img-responsive" />
                    <?php if($aboutusdescription) { ?>
					<p><?php echo $aboutusdescription ?></p>
                    <?php } ?>
                </div><!--/.span6-->

                <div class="span6 wow fadeInDown">
                    <div class="accordion">
                        <div class="panel-group" id="accordion1">
                          <div class="panel panel-default">
                              <?php if($accordionbox1heading) { ?>
                            <div class="panel-heading active">
                              <h3 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapseOne1">
                                  <?php echo $accordionbox1heading ?>
                                  <i class="fa fa-angle-right pull-right"></i>
                                </a>
                              </h3>
                            </div>
                            <?php } ?>
                              <?php if($accordionbox1description){ ?>
                            <div id="collapseOne1" class="panel-collapse collapse in">
                              <div class="panel-body">
									<?php echo $accordionbox1description ?>
								</div>
                            </div>
                              <?php } ?>
                          </div>

                          <div class="panel panel-default">
                              <?php if($accordionbox2heading) { ?>
                            <div class="panel-heading">
                              <h3 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapseTwo1">
                                  <?php echo $accordionbox2heading ?>
                                  <i class="fa fa-angle-right pull-right"></i>
                                </a>
                              </h3>
                            </div>
                              <?php } ?>
                              <?php if($accordionbox2description) { ?>
                            <div id="collapseTwo1" class="panel-collapse collapse">
								<div class="panel-body">
									<?php echo $accordionbox2description ?>
								</div>
                            </div>
                              <?php } ?>
                          </div>

                          <div class="panel panel-default">
                              <?php if($accordionbox3heading) { ?>
                            <div class="panel-heading">
                              <h3 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapseThree1">
                                  <?php echo $accordionbox3heading ?>
                                  <i class="fa fa-angle-right pull-right"></i>
                                </a>
                              </h3>
                            </div>
                              <?php } ?>
                              <?php if($accordionbox3description) { ?>
                            <div id="collapseThree1" class="panel-collapse collapse">
                              <div class="panel-body">
                                <?php echo $accordionbox3description ?>
                              </div>
                            </div>
                              <?php } ?>
                          </div>

                          <div class="panel panel-default">
                              <?php if($accordionbox4heading) { ?>
                            <div class="panel-heading">
                              <h3 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapseFour1">
                                  <?php echo $accordionbox4heading ?>
                                  <i class="fa fa-angle-right pull-right"></i>
                                </a>
                              </h3>
                            </div>
                              <?php } ?>
                              <?php if($accordionbox4description) { ?>
                            <div id="collapseFour1" class="panel-collapse collapse">
								<div class="panel-body">
								   <?php echo $accordionbox4description ?>
								</div>
                            </div>
                              <?php } ?>
                          </div>
                        </div><!--/#accordion1-->
                    </div>
                </div>

            </div><!--/.row-->
        </div><!--/.container-->
    </section><!--/#about-->
<?php } ?>