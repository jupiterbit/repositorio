<!-- Start Breadcrumb Section -->
<div id="page-navbar" class="clearfix">
   <div class="container-fluid">
      <nav class="breadcrumb-nav"><?php echo $OUTPUT->navbar(); ?></nav>
      <div class="breadcrumb-button"><?php echo $OUTPUT->page_heading_button(); ?></div>
   </div>
</div>
<!-- End Breadcrumb Section -->